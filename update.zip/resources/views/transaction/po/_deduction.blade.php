<div class="card-header d-flex justify-content-between align-items-center">
  <h5 class="mb-0">Deduction</h5>
  <button id="add_row_deduction" type="button" class="btn btn-primary">+</button>
</div>
<div class="table-container">
  <table class="table table-scroll" id="deduction_table">
    <thead>
      <tr>
        <th>No</th>
        <th>Description</th>
        <th>Deduction</th>
        <th>Amount</th>
        <th>Qty</th>
        <th>Total</th>
        <th></th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>
</div>