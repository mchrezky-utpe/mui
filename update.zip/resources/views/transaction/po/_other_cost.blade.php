   <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Other Cost</h5>
        <button id="add_row_other_cost" type="button" class="btn btn-primary">+</button>
    </div>
    <div class="table-container">
        <table class="table table-scroll" id="other_cost_table">
          <thead>
            <tr>
              <th>No</th>
              <th>Description</th>
              <th>Other Cost</th>
              <th>Amount</th>
              <th>Qty</th>
              <th>Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>