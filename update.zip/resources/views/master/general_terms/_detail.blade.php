<div class="card-header d-flex justify-content-between align-items-center">
  <h5 class="mb-0">Details</h5>
  <button id="add_row_detail" type="button" class="btn btn-primary add_row_detail">+</button>
</div>
<div class="table-container">
  <table class="table table-scroll detail_table" id="detail_table">
    <thead>
      <tr>
        <th>No</th>
        <th>Description</th>
        <th></th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>
</div>