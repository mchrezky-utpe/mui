<x-modals.modal id="set_code_modal" title="Set Code">
  <h2>Select Set Code</h2>
  <ul id="setCodeList"></ul>
</x-modals.modal>