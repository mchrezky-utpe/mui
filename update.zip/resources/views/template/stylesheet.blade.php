<!-- Fontfaces CSS-->
<link href="{{asset('assets/css/font-face.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/font-awesome-4.7/css/font-awesome.min.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/font-awesome-5/css/fontawesome-all.min.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/mdi-font/css/material-design-iconic-font.min.css')}}" rel="stylesheet" media="all">

<!-- Bootstrap CSS-->
<link href="{{asset('assets/vendor/bootstrap-4.1/bootstrap.min.css')}}" rel="stylesheet" media="all">

<!-- Vendor CSS-->
<link href="{{asset('assets/vendor/animsition/animsition.min.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/wow/animate.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/css-hamburgers/hamburgers.min.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/slick/slick.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/select2/select2.min.css')}}" rel="stylesheet" media="all">
<link href="{{asset('assets/vendor/perfect-scrollbar/perfect-scrollbar.css')}}" rel="stylesheet" media="all">

<!-- Main CSS-->
<link href="{{asset('assets/css/theme.css')}}" rel="stylesheet" media="all">
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css">

<style>
.custom-modal-dialog-large {
    max-width: 1700px; /* Lebar modal */
    margin: 0 auto; /* Memastikan modal tetap berada di tengah horizontal */
}
.custom-modal-dialog-medium {
    max-width: 900px; /* Lebar modal */
    margin: 0 auto; /* Memastikan modal tetap berada di tengah horizontal */
}
.custom-modal-dialog-medium2 {
    max-width: 1000px; /* Lebar modal */
    margin: 0 auto; /* Memastikan modal tetap berada di tengah horizontal */
}


.custom-modal-dialog-large .modal-content {
    height: auto; /* Sesuaikan tinggi konten jika diperlukan */
    overflow-y: auto; /* Tambahkan scroll jika konten terlalu panjang */
}


table.dataTable tbody {
    font-size: 11px;
}
table.dataTable thead {
    font-size: 12px;
}
table.dataTable tbody td {
    padding: 2px 2px; /* Atur sesuai kebutuhan */
}
table.dataTable thead th {
    padding: 2px;
}
.row {
    margin-right: 2px;
    margin-left: 2px;
}
body {
    font-weight: 500;
    font-size: 13px;
}
.form-group {
    margin: 0.2rem;
}
.btn {
    margin: 2px;
}
</style>
